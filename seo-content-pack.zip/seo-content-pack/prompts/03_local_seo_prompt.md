# Prompt 03 — Local SEO Content Adaptation

## Purpose
Adapt any existing blog or service page to rank for local searches like
"[service] in [city]" — the most valuable keyword format for local businesses.

---

## ✅ The Prompt

```
You are a local SEO specialist. Your job is to adapt the following blog/content to target local search traffic in [CITY].

ORIGINAL CONTENT:
[PASTE YOUR EXISTING BLOG OR PAGE CONTENT HERE]

BUSINESS DETAILS:
- Business Name: [NAME]
- City: [CITY]
- State: [STATE]
- Primary Local Keyword: "[SERVICE] in [CITY]"
- Nearby Areas to Mention: [LIST 3–5 NEIGHBOURHOODS OR NEARBY CITIES]

LOCAL SEO TASKS — rewrite or enhance the content to:

1. TITLE & H1:
   - Ensure the city name appears in the H1 naturally
   - Format: "[Service] in [City] – [Benefit or Hook]"

2. INTRO PARAGRAPH:
   - Mention the city in the first 100 words
   - Reference a local pain point or local market fact

3. LOCAL SIGNALS (add throughout):
   - Mention specific areas/neighborhoods served (e.g., Banjara Hills, Gachibowli, HITEC City)
   - Add a "Areas We Serve in [City]" H2 section
   - Include a sentence about local business landscape (e.g., "With 10,000+ startups in Hyderabad...")

4. META DATA:
   - Rewrite Meta Title: include city + primary keyword (under 60 chars)
   - Rewrite Meta Description: include city + CTA (under 160 chars)

5. SCHEMA MARKUP SUGGESTION:
   - Suggest LocalBusiness schema fields:
     @type, name, address, telephone, areaServed, url

6. INTERNAL LINKS:
   - Suggest 2 internal links to other location-specific pages or blogs

OUTPUT FORMAT:
New Meta Title: ...
New Meta Description: ...
LocalBusiness Schema (JSON-LD skeleton): ...
---
[Full rewritten/enhanced blog content]
---
Areas We Serve section:
Internal Link Suggestions:
```

---

## 📌 Example (PixelRank Digital — Hyderabad)

| Field | Value |
|---|---|
| City | Hyderabad |
| State | Telangana |
| Primary Local Keyword | digital marketing agency in Hyderabad |
| Nearby Areas | Banjara Hills, Gachibowli, HITEC City, Madhapur, Jubilee Hills, Secunderabad |
| Local Fact | "Hyderabad is home to 300,000+ registered businesses and a booming startup ecosystem" |

---

## 💡 Pro Tip: City Variation Prompt

```
Now adapt the same blog for these additional cities by replacing "Hyderabad" with:
1. Vijayawada
2. Visakhapatnam
3. Warangal

Keep all content the same structure but localize: city name, nearby areas, local facts.
Generate all 3 versions.
```

This lets agencies create city-specific landing pages at scale.
