# Prompt 04 — Keyword Research & Intent Mapping

## Purpose
Use AI to build a keyword map before writing any content — so every blog
targets a real search query with clear intent.

---

## ✅ The Prompt

```
You are an SEO keyword strategist working for a [BUSINESS TYPE] in [CITY], India.

BUSINESS: [BUSINESS NAME]
SERVICE OFFERINGS: [LIST YOUR MAIN SERVICES]
LOCATION: [CITY, STATE]

Your task: Build a complete keyword research map for a content cluster strategy.

STEP 1 — SEED KEYWORDS
List 10 primary (short-tail) keywords for this business.
Format: keyword | monthly search intent guess | competition level (Low/Med/High)

STEP 2 — LONG-TAIL KEYWORDS
For each primary keyword, generate 3–5 long-tail variants.
Focus on:
- Question-based keywords (How to, What is, Why, Which)
- Location-based keywords ([service] in [city], best [service] [city])
- Price/comparison keywords (cost of, [A] vs [B], affordable [service])
- Problem-based keywords (how to fix, how to improve, why is my...)

STEP 3 — SEARCH INTENT CLASSIFICATION
For each keyword cluster, classify the intent:
- INFORMATIONAL: User wants to learn (write blog posts)
- COMMERCIAL INVESTIGATION: User is comparing options (write comparison blogs, reviews)
- TRANSACTIONAL: User wants to buy/contact (write service pages, landing pages)
- NAVIGATIONAL: User is looking for a specific brand (optimize homepage/About)

STEP 4 — CONTENT ASSIGNMENT
Map each keyword to a recommended content type:
- Pillar blog
- Supporting blog
- Service page
- FAQ page
- Landing page

OUTPUT FORMAT:
## Seed Keywords
| Keyword | Intent | Competition | Best Content Type |
|---------|--------|-------------|-------------------|

## Long-tail Keyword Clusters
### Cluster 1: [Primary Keyword]
| Long-tail Keyword | Intent | Recommended Blog Title |
|------------------|--------|----------------------|

[Repeat for each cluster]

## Priority Recommendations
List the top 5 keywords to target first and why.
```

---

## 📌 Example Seed Keywords (PixelRank Digital)

| Keyword | Intent | Competition | Content Type |
|---|---|---|---|
| digital marketing agency Hyderabad | Commercial | High | Pillar Blog |
| SEO services Hyderabad | Commercial | Med | Supporting Blog |
| social media marketing Hyderabad | Commercial | Med | Supporting Blog |
| Google Ads agency Hyderabad | Transactional | Med | Service Page |
| digital marketing cost Hyderabad | Commercial | Low | Supporting Blog |
| how to rank on Google Hyderabad | Informational | Low | Supporting Blog |
| best digital marketing agency India | Commercial | High | Pillar Blog |
| content marketing services Hyderabad | Commercial | Low | Service Page |
| local SEO Hyderabad | Commercial | Low | Supporting Blog |
| Instagram marketing Hyderabad | Commercial | Low | Supporting Blog |
