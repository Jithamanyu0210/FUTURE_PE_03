# Prompt 01 — Pillar Blog Generator

## Purpose
Generate a long-form SEO pillar blog (2,500–3,000 words) for a business website.
This is the main content hub that all supporting blogs will link back to.

---

## ✅ The Prompt (Copy & Paste into Claude / ChatGPT / Gemini)

```
You are an expert SEO content writer with 10+ years of experience writing long-form blogs for digital agencies and local businesses in India.

Write a comprehensive, SEO-optimized pillar blog for the following business:

Business Name: [BUSINESS NAME]
Business Type: [BUSINESS TYPE, e.g., Digital Marketing Agency]
Location: [CITY, STATE, INDIA]
Primary Keyword: [PRIMARY KEYWORD, e.g., "digital marketing agency in Hyderabad"]
Secondary Keywords: [LIST 3–5 SECONDARY KEYWORDS]
Target Audience: [WHO IS THIS FOR, e.g., "small business owners in Hyderabad looking to grow online"]
Word Count Target: 2,500–3,000 words
Tone: Professional, helpful, trustworthy — NOT salesy

STRUCTURE REQUIREMENTS:
- H1: Include the primary keyword naturally
- H2 sections: At least 6 major sections
- H3 subsections: Use where needed for clarity
- Include a meta title (under 60 characters) and meta description (under 160 characters)
- Add an FAQ section with 5 real questions people search on Google
- End with a strong CTA paragraph encouraging the reader to contact [BUSINESS NAME]

SEO REQUIREMENTS:
- Use primary keyword in H1, first paragraph, one H2, and conclusion
- Use secondary keywords naturally in body paragraphs
- Include at least 3 internal linking suggestions (format: [LINK: suggested blog title])
- Write in short paragraphs (2–4 sentences max)
- No keyword stuffing — write for humans first, search engines second

CONTENT REQUIREMENTS:
- Explain who the business serves and why they are a trusted choice
- Cover all major services offered
- Include a section about why [CITY] businesses specifically need this service
- Add real-world value: tips, data points, comparisons
- Sound like a knowledgeable expert, not a salesperson

OUTPUT FORMAT:
Meta Title: ...
Meta Description: ...
---
[Full blog content with H1, H2, H3 headings]
---
FAQ Section
Internal Linking Suggestions
CTA
```

---

## 📌 Example Values (PixelRank Digital)

| Field | Value |
|---|---|
| Business Name | PixelRank Digital |
| Business Type | Digital Marketing Agency |
| Location | Hyderabad, Telangana |
| Primary Keyword | digital marketing agency in Hyderabad |
| Secondary Keywords | SEO agency Hyderabad, social media marketing Hyderabad, Google Ads Hyderabad, online marketing services Hyderabad |
| Target Audience | Small business owners, startups, and entrepreneurs in Hyderabad looking for ROI-driven digital marketing |

---

## 🔁 Reusability

Replace the values in [BRACKETS] to use this prompt for:
- A dental clinic in Bangalore
- A coaching institute in Pune
- A salon in Chennai
- Any local business in any Indian city
