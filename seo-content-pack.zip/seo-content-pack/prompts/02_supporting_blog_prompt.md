# Prompt 02 — Supporting Blog Generator (Content Cluster)

## Purpose
Generate focused, medium-length supporting blogs (800–1,200 words) that target long-tail keywords and link back to the pillar blog.

---

## ✅ The Prompt

```
You are an SEO content writer creating a supporting blog for a content cluster strategy.

Write a focused, SEO-optimized blog post for:

Business Name: [BUSINESS NAME]
Location: [CITY]
Blog Topic: [SPECIFIC TOPIC, e.g., "SEO Services in Hyderabad"]
Target Keyword: [LONG-TAIL KEYWORD, e.g., "SEO services in Hyderabad for small businesses"]
Search Intent: [INTENT TYPE: Informational / Commercial / Transactional]
Word Count: 900–1,200 words
Pillar Blog Title: [TITLE OF THE MAIN PILLAR BLOG — this supporting blog must link to it]
Tone: Helpful, clear, approachable — like advice from an expert friend

STRUCTURE:
- Meta Title (under 60 characters, include keyword)
- Meta Description (under 160 characters)
- H1: Hook the reader with a question or bold claim that includes the keyword
- Introduction (2–3 short paragraphs): Address the reader's pain point
- 3–5 H2 sections covering the topic in depth
- Use H3s for sub-points or step-by-step breakdowns
- FAQ section: 3–4 real questions from Google's "People Also Ask"
- Conclusion with soft CTA + internal link to pillar blog

SEO RULES:
- Include target keyword in H1, intro paragraph, one H2 heading, and conclusion
- Naturally mention the city/location at least 3–4 times
- Add 1–2 internal link suggestions to related supporting blogs
- Keep paragraphs short (2–3 sentences)
- Write for a reader who is in the MIDDLE of their research — not a beginner, not an expert

OUTPUT FORMAT:
Meta Title: ...
Meta Description: ...
---
[Full Blog Content]
---
Internal Link Suggestions:
- Link to: [blog title 1]
- Link to: [pillar blog title]
```

---

## 📌 Batch Mode (Generate All 5 Supporting Blogs at Once)

```
Using the above prompt structure, generate 5 separate supporting blogs for [BUSINESS NAME] in [CITY].

Blog topics and target keywords:
1. Topic: SEO Services in [CITY] | Keyword: "SEO services in [CITY] for small businesses"
2. Topic: Social Media Marketing in [CITY] | Keyword: "social media marketing agency [CITY]"
3. Topic: Digital Marketing Cost | Keyword: "how much does digital marketing cost in [CITY]"
4. Topic: How to Choose an Agency | Keyword: "how to choose the right digital marketing agency in India"
5. Topic: Google Ads vs SEO | Keyword: "Google Ads vs SEO which is better [CITY]"

For each blog:
- Write 900–1,000 words
- Include Meta Title + Meta Description
- Use proper H1/H2/H3 structure
- Add internal linking suggestions
- End with CTA linking to the pillar blog

Generate all 5, clearly separated.
```

---

## 🔁 Reusability Notes

- Change [CITY] to any Indian city
- Change topics to match any business type
- The batch mode saves 70% of prompt writing time
