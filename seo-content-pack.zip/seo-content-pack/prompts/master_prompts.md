# 🧠 Master Prompt System — SEO Blog Generator
## Reusable Prompts for Any Business, Any City

> Replace all [PLACEHOLDERS] with your client's details before running.

---

## PROMPT 1 — Content Cluster Planner

Use this FIRST to map your entire content strategy.

```
You are an expert SEO content strategist with 10+ years of experience building
topical authority for local businesses.

My client is a [BUSINESS TYPE] based in [CITY], [STATE], India.
Their primary service is [PRIMARY SERVICE].
Their website is [WEBSITE URL].

Task:
1. Suggest 1 pillar blog topic targeting the keyword "[PRIMARY KEYWORD] in [CITY]"
2. Suggest 5 supporting blog topics that form a content cluster around this pillar
3. For each blog, provide:
   - Target keyword (primary + 2 secondary)
   - Search intent (informational / commercial / transactional)
   - Estimated word count
   - Internal linking suggestion (which blogs should link to each other)
4. Create a content cluster map showing the relationship between all 6 blogs

Format your response as a structured table + cluster diagram.
Keep all keywords realistic for a local business in [CITY].
```

---

## PROMPT 2 — Pillar Blog Generator

Use this to generate the main 2000+ word pillar article.

```
You are an expert SEO blog writer specializing in local business content for India.

Write a comprehensive, SEO-optimized pillar blog post for the following:

BUSINESS: [BRAND NAME]
BUSINESS TYPE: [BUSINESS TYPE]
CITY: [CITY], [STATE]
PRIMARY KEYWORD: "[PRIMARY KEYWORD] in [CITY]"
SECONDARY KEYWORDS: [KEYWORD 2], [KEYWORD 3], [KEYWORD 4]
TARGET AUDIENCE: [describe audience — e.g., small business owners in Hyderabad]
WORD COUNT: 2,000–2,500 words
TONE: Professional yet conversational, helpful, trustworthy

Structure Requirements:
- H1: Include primary keyword naturally (not forced)
- H2 sections (6–8): Cover services, benefits, how to choose, local context, FAQs, CTA
- H3 subsections under each H2
- Include these exact sections:
  * Introduction (hook + problem statement, 150 words)
  * What Is [Service]? (definition + context)
  * Why [CITY] Businesses Need [Service]
  * Services Offered (list with brief description)
  * How to Choose the Right [Business Type] in [CITY]
  * What Results Can You Expect?
  * Frequently Asked Questions (5 PAA-style questions)
  * Conclusion + CTA

Additional Requirements:
- Mention [CITY] naturally at least 6 times
- Include [INTERNAL LINK] markers where supporting blogs should be linked
- End with a strong CTA to contact [BRAND NAME]
- Add a meta description (155 characters max) at the top
- Add a suggested URL slug at the top
- Do NOT keyword-stuff — write naturally for humans first
- Include 1 real stat or data point per major section (you can create plausible ones for India)

Write the full blog now.
```

---

## PROMPT 3 — Supporting Blog Generator (Cluster Article)

Use this for each of the 5 supporting blogs.

```
You are an expert SEO content writer for local businesses in India.

Write an SEO-optimized supporting blog post for:

PARENT BRAND: [BRAND NAME] — [BUSINESS TYPE] in [CITY]
BLOG TOPIC: [BLOG TOPIC]
PRIMARY KEYWORD: "[PRIMARY KEYWORD]"
SECONDARY KEYWORDS: [KEYWORD 2], [KEYWORD 3]
SEARCH INTENT: [informational / commercial / transactional]
WORD COUNT: 900–1,200 words
TONE: Helpful, clear, trustworthy

Structure:
- Meta description (155 chars max)
- URL slug suggestion
- H1: Contains primary keyword
- H2 sections (4–5): Cover topic thoroughly
- H3 subsections with PAA-style questions
- Bullet points where appropriate for scannability
- [INTERNAL LINK] markers for 2–3 links to other cluster blogs
- Conclusion with CTA to visit main services page

Context:
This blog is part of a content cluster. The pillar blog is:
"[PILLAR BLOG TITLE]" — [PILLAR BLOG URL]
Link to this pillar blog once using natural anchor text.

Additional:
- Mention [CITY] at least 4 times
- Do not repeat content from the pillar — go deeper on this specific subtopic
- End with a FAQ section (3 questions)

Write the full blog now.
```

---

## PROMPT 4 — Local SEO Content Adapter

Use this to adapt any existing blog for a new city/location.

```
You are a local SEO specialist. I have an existing blog post and I need to
adapt it for a different city/location while keeping the same structure.

ORIGINAL BLOG: [paste blog here]
ORIGINAL CITY: [OLD CITY]
NEW CITY: [NEW CITY], [STATE]
NEW BRAND NAME: [NEW BRAND NAME]

Task:
1. Replace all mentions of [OLD CITY] with [NEW CITY] naturally
2. Update any local references (areas, landmarks, business districts)
3. Replace the brand name throughout
4. Update the meta description with the new city
5. Update the URL slug
6. Add 2–3 new sentences that reference specific aspects of [NEW CITY]
   (e.g., business hubs, local economy, industries common in that city)
7. Keep all H1–H3 structure intact
8. Ensure the tone and content remain natural — not just find-replace

Deliver the fully adapted blog post.
```

---

## PROMPT 5 — Internal Link Suggester

Use this after all blogs are written to plan internal linking.

```
You are an SEO internal linking specialist.

I have written 6 blog posts for [BRAND NAME], a [BUSINESS TYPE] in [CITY].
Here are the titles and primary keywords:

1. [PILLAR BLOG TITLE] — keyword: [KEYWORD]
2. [BLOG 1 TITLE] — keyword: [KEYWORD]
3. [BLOG 2 TITLE] — keyword: [KEYWORD]
4. [BLOG 3 TITLE] — keyword: [KEYWORD]
5. [BLOG 4 TITLE] — keyword: [KEYWORD]
6. [BLOG 5 TITLE] — keyword: [KEYWORD]

Task:
For each blog, suggest:
- Which 2–3 other blogs it should link TO
- Suggested anchor text for each link (partial-match, natural)
- WHERE in the blog (intro, middle, conclusion) to place the link
- Whether the link should open in same tab (internal) or new tab

Format as a table with columns:
Blog | Links To | Anchor Text | Placement | Tab
```

---

## PROMPT 6 — Meta Description Batch Writer

Use this to write all meta descriptions at once.

```
Write SEO-optimized meta descriptions for the following 6 blog posts.
Each must be exactly 145–158 characters (including spaces).
Each must include the primary keyword and a call to action.

Business: [BRAND NAME] — [BUSINESS TYPE] in [CITY]

Blogs:
1. Title: [TITLE] | Keyword: [KEYWORD]
2. Title: [TITLE] | Keyword: [KEYWORD]
3. Title: [TITLE] | Keyword: [KEYWORD]
4. Title: [TITLE] | Keyword: [KEYWORD]
5. Title: [TITLE] | Keyword: [KEYWORD]
6. Title: [TITLE] | Keyword: [KEYWORD]

Format: Blog number, meta description, character count.
```

---

## 🔄 How to Reuse These Prompts for Any Client

### Step 1 — Fill in the variables:
| Placeholder | Example |
|-------------|---------|
| [BRAND NAME] | PixelRank Digital |
| [BUSINESS TYPE] | digital marketing agency |
| [CITY] | Hyderabad |
| [STATE] | Telangana |
| [PRIMARY SERVICE] | SEO + social media marketing |
| [PRIMARY KEYWORD] | digital marketing agency |
| [WEBSITE URL] | pixelrankdigital.com |

### Step 2 — Run in this order:
1. Prompt 1 (Cluster Planner) → get your blog topics
2. Prompt 2 (Pillar Blog) → write the main article
3. Prompt 3 x5 (Supporting Blogs) → write each cluster blog
4. Prompt 5 (Internal Links) → connect everything
5. Prompt 6 (Meta Descriptions) → finalize for SEO

### Step 3 — Publish & monitor:
- Publish pillar first, then supporting blogs over 2–4 weeks
- Add internal links as each blog goes live
- Monitor rankings at 30, 60, 90 days
