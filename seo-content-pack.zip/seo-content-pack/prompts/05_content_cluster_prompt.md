# Prompt 05 — Content Cluster Strategy Builder

## Purpose
Plan the entire content cluster before writing a single word —
so all blogs work together as a system, not random articles.

---

## ✅ The Prompt

```
You are a senior SEO content strategist. Create a complete content cluster plan for:

Business: [BUSINESS NAME]
Type: [BUSINESS TYPE]
Location: [CITY]
Primary Topic / Pillar Keyword: [PRIMARY KEYWORD]
Business Goal: [GOAL — e.g., generate leads, build authority, rank locally]

BUILD A CONTENT CLUSTER with the following output:

1. PILLAR BLOG PLAN
   - Suggested H1 title (include primary keyword)
   - Meta description (160 chars)
   - 6–8 H2 section titles
   - Estimated word count
   - Primary keyword + 4 secondary keywords
   - Internal linking plan: which supporting blogs to link to

2. SUPPORTING BLOGS (generate 5)
   For each supporting blog:
   - Blog title (with target keyword)
   - Target keyword
   - Search intent (Informational / Commercial / Transactional)
   - 4 H2 section titles
   - Word count (800–1,200)
   - Which blogs it should internally link to

3. INTERNAL LINKING MAP
   Draw a simple text-based diagram showing:
   - Pillar blog at the center
   - Supporting blogs linking to it
   - Cross-links between supporting blogs where relevant

4. PUBLICATION ORDER
   Recommend which blogs to publish first, second, etc., and why.
   (Usually: pillar last, supporting blogs first)

5. CONTENT CALENDAR
   Suggest a 6-week publication schedule.

OUTPUT FORMAT:
## Pillar Blog Plan
## Supporting Blog 1–5 Plans
## Internal Linking Map (text diagram)
## Publication Order + Reasoning
## 6-Week Content Calendar
```

---

## 📌 Cluster Summary (PixelRank Digital — Generated Output)

```
PILLAR
└── Best Digital Marketing Agency in Hyderabad (Publish: Week 6)

SUPPORTING (Publish order)
├── Week 1: How Much Does Digital Marketing Cost in Hyderabad?
├── Week 2: SEO Services in Hyderabad – How to Rank Your Business
├── Week 3: Social Media Marketing for Businesses in Hyderabad
├── Week 4: How to Choose the Right Digital Marketing Agency
└── Week 5: Google Ads vs SEO – Which Is Better for Hyderabad Businesses?

INTERNAL LINK MAP
┌─────────────────────────────────────────┐
│           PILLAR BLOG (Hub)             │
│  Best Digital Marketing Agency Hyd      │
└──────────────┬──────────────────────────┘
               │ links to all 5 supporting blogs
       ┌───────┼──────────────────────────┐
       ▼       ▼       ▼       ▼          ▼
   [Cost]  [SEO]  [SMM]  [Choose]  [Ads vs SEO]
     │       │              │
     └───────┘              └──→ links back to pillar
```

---

## 💡 Why Supporting Blogs First?

Publishing supporting blogs first lets them:
1. Get indexed by Google before the pillar goes live
2. Start attracting traffic and internal link juice
3. Create a "topical authority signal" — Google sees you as an expert on the topic
4. Give the pillar blog existing pages to link to on day one

This is the strategy used by HubSpot, Backlinko, and Ahrefs.
